package com.youtube.jwt;



import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.core.SpringVersion;

@SpringBootApplication
public class ImplementingTokenAndRolesApplication {

	public static void main(String[] args) {
		SpringApplication.run(ImplementingTokenAndRolesApplication.class, args);
		System.out.print("spring version");
		System.out.println( SpringVersion.getVersion());
	}

}
